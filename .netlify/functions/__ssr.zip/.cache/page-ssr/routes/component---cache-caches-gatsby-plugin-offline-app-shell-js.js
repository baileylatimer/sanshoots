"use strict";
exports.id = 306;
exports.ids = [306];
exports.modules = {

/***/ 1367:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireDefault = __webpack_require__(4836);
exports.__esModule = true;
exports["default"] = void 0;
var _inheritsLoose2 = _interopRequireDefault(__webpack_require__(7867));
var _react = _interopRequireDefault(__webpack_require__(199));
var AppShell = /*#__PURE__*/function (_React$Component) {
  (0, _inheritsLoose2.default)(AppShell, _React$Component);
  function AppShell() {
    return _React$Component.apply(this, arguments) || this;
  }
  var _proto = AppShell.prototype;
  _proto.render = function render() {
    return /*#__PURE__*/_react.default.createElement(_react.default.Fragment, null);
  };
  return AppShell;
}(_react.default.Component);
var _default = AppShell;
exports["default"] = _default;

/***/ })

};
;
//# sourceMappingURL=component---cache-caches-gatsby-plugin-offline-app-shell-js.js.map